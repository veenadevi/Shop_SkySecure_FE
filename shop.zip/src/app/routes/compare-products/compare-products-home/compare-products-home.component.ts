import { Component } from '@angular/core';

@Component({
  selector: 'app-compare-products-home',
  templateUrl: './compare-products-home.component.html',
  styleUrls: ['./compare-products-home.component.css']
})
export class CompareProductsHomeComponent {

}
