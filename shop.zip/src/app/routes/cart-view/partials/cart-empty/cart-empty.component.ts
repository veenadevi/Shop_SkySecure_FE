import { Component } from '@angular/core';

@Component({
  selector: 'app-cart-empty',
  templateUrl: './cart-empty.component.html',
  styleUrls: ['./cart-empty.component.css']
})
export class CartEmptyComponent {

}
