import { Component } from '@angular/core';

@Component({
  selector: 'app-upload-product-price',
  templateUrl: './upload-product-price.component.html',
  styleUrls: ['./upload-product-price.component.css']
})
export class UploadProductPriceComponent {

}
