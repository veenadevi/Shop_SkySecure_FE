import { OEMDetails  } from "../partials/oem-details"

export interface OEMResponse{
	oems : OEMDetails[];
}