import { CategoryDetails  } from "../partials/category-details"

export interface CatrgoryResponse{
	categorys : CategoryDetails[];
}