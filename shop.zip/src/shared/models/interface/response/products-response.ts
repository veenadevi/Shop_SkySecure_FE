import { ProductsDetails  } from "../partials/products-details";

export interface ProductsResponse{
	products : ProductsDetails[];
}