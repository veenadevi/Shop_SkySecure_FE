export interface OEMDetails{
	_id: string,
    name: string,
    description: string,
    imageURL:string,
    createdBy: string,
    updatedBy: string,
    createdAt: Date,
    updatedAt: Date,
    __v: number
}