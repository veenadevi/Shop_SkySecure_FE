export interface UserDetails {
    company : string;
    createdAt : string;
    createdBy : string;
    email : string;
    firstName : string;
    lastName : string;
    role : string;
    updatedAt
    updatedBy
    __v : number;
    _id : string;
    userId : string;
}