export interface UserCartDetails{
    cart_ref_id : string;
    productId : string;
    quantity : string;
    createdAt : string;
    updatedAt : string;
    __v : string;
    _id : string;
}