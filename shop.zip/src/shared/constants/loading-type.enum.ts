export enum LoadingType {
    Full = 'full',
    Table = 'table',
    Partial = 'partial'
  }